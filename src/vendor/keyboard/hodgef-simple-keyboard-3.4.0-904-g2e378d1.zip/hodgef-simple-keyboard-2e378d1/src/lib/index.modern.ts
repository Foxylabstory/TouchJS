import SimpleKeyboard from "./components/Keyboard";
export { SimpleKeyboard };
export default SimpleKeyboard;
